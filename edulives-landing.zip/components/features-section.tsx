import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import {
  GraduationCap,
  Users,
  Calendar,
  BarChart3,
  Shield,
  Smartphone,
  BookOpen,
  CreditCard,
  MessageSquare,
  FileText,
  Clock,
  Award,
} from "lucide-react"

const features = [
  {
    icon: GraduationCap,
    title: "Student Management",
    description: "Complete student lifecycle management from admission to graduation with detailed academic records.",
  },
  {
    icon: Users,
    title: "Staff Management",
    description: "Comprehensive staff profiles, attendance tracking, and performance management system.",
  },
  {
    icon: Calendar,
    title: "Timetable Management",
    description: "Automated timetable generation with conflict detection and easy schedule modifications.",
  },
  {
    icon: BarChart3,
    title: "Analytics & Reports",
    description: "Detailed insights and customizable reports for academic performance and operational metrics.",
  },
  {
    icon: CreditCard,
    title: "Fee Management",
    description: "Streamlined fee collection, payment tracking, and automated receipt generation.",
  },
  {
    icon: MessageSquare,
    title: "Communication Hub",
    description: "Integrated messaging system connecting teachers, students, and parents seamlessly.",
  },
  {
    icon: BookOpen,
    title: "Library Management",
    description: "Digital catalog management with book tracking and automated fine calculations.",
  },
  {
    icon: FileText,
    title: "Examination System",
    description: "Complete exam management from scheduling to result publication and analysis.",
  },
  {
    icon: Shield,
    title: "Security & Privacy",
    description: "Enterprise-grade security with role-based access control and data encryption.",
  },
  {
    icon: Smartphone,
    title: "Mobile App",
    description: "Native mobile applications for iOS and Android with offline capabilities.",
  },
  {
    icon: Clock,
    title: "Attendance Tracking",
    description: "Biometric and RFID integration for accurate attendance monitoring.",
  },
  {
    icon: Award,
    title: "Certificate Generation",
    description: "Automated generation of certificates, transcripts, and official documents.",
  },
]

export function FeaturesSection() {
  return (
    <section id="features" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-900">Everything You Need to Manage Your School</h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Our comprehensive platform covers every aspect of school management, from academics to administration, all
            in one integrated solution.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <Card key={index} className="border-slate-200 hover:shadow-lg transition-shadow duration-300">
              <CardHeader>
                <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center mb-4">
                  <feature.icon className="w-6 h-6 text-blue-600" />
                </div>
                <CardTitle className="text-slate-900">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-slate-600">{feature.description}</CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
