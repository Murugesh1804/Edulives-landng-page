import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Check } from "lucide-react"

const plans = [
  {
    name: "Starter",
    price: "₹2,999",
    period: "/month",
    description: "Perfect for small schools up to 200 students",
    features: [
      "Up to 200 students",
      "Basic student management",
      "Attendance tracking",
      "Fee management",
      "Parent communication",
      "Mobile app access",
      "Email support",
    ],
    popular: false,
  },
  {
    name: "Professional",
    price: "₹5,999",
    period: "/month",
    description: "Ideal for medium schools up to 1000 students",
    features: [
      "Up to 1000 students",
      "Advanced analytics",
      "Inventory management",
      "Examination system",
      "Library management",
      "Transport tracking",
      "Priority support",
      "Custom reports",
    ],
    popular: true,
  },
  {
    name: "Enterprise",
    price: "Custom",
    period: "pricing",
    description: "For large institutions with unlimited students",
    features: [
      "Unlimited students",
      "Multi-campus support",
      "Advanced integrations",
      "Custom workflows",
      "Dedicated support",
      "Training & onboarding",
      "SLA guarantee",
      "White-label options",
    ],
    popular: false,
  },
]

export function PricingSection() {
  return (
    <section id="pricing" className="py-20 bg-white">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-900">Simple, Transparent Pricing</h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            Choose the plan that fits your school's needs. All plans include core features with no hidden fees or setup
            costs.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {plans.map((plan, index) => (
            <Card
              key={index}
              className={`relative border-slate-200 ${plan.popular ? "ring-2 ring-blue-600 shadow-lg" : ""}`}
            >
              {plan.popular && (
                <Badge className="absolute -top-3 left-1/2 transform -translate-x-1/2 bg-blue-600 text-white">
                  Most Popular
                </Badge>
              )}
              <CardHeader className="text-center">
                <CardTitle className="text-2xl text-slate-900">{plan.name}</CardTitle>
                <div className="mt-4">
                  <span className="text-4xl font-bold text-slate-900">{plan.price}</span>
                  <span className="text-slate-600">{plan.period}</span>
                </div>
                <CardDescription className="mt-2">{plan.description}</CardDescription>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3 mb-8">
                  {plan.features.map((feature, featureIndex) => (
                    <li key={featureIndex} className="flex items-center space-x-3">
                      <Check className="w-5 h-5 text-green-600 flex-shrink-0" />
                      <span className="text-slate-700">{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button
                  className={`w-full ${plan.popular ? "bg-blue-600 hover:bg-blue-700" : "bg-slate-900 hover:bg-slate-800"} text-white`}
                >
                  {plan.name === "Enterprise" ? "Contact Sales" : "Start Free Trial"}
                </Button>
              </CardContent>
            </Card>
          ))}
        </div>

        <div className="text-center mt-12">
          <p className="text-slate-600 mb-4">All plans include a 30-day free trial. No credit card required.</p>
          <div className="flex justify-center items-center space-x-8 text-sm text-slate-500">
            <span>✓ Free setup & migration</span>
            <span>✓ 24/7 customer support</span>
            <span>✓ 99.9% uptime guarantee</span>
          </div>
        </div>
      </div>
    </section>
  )
}
