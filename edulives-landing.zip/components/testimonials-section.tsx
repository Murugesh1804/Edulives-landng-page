import { Card, CardContent } from "@/components/ui/card"
import { Star } from "lucide-react"
import Image from "next/image"

const testimonials = [
  {
    name: "Dr. Sarah Johnson",
    role: "Principal, Greenwood High School",
    image: "/placeholder.svg?height=80&width=80",
    content:
      "Edulives has transformed how we manage our school. The comprehensive dashboard and role-based access have streamlined our operations significantly.",
    rating: 5,
  },
  {
    name: "Michael Chen",
    role: "IT Administrator, Riverside Academy",
    image: "/placeholder.svg?height=80&width=80",
    content:
      "The inventory management system alone has saved us countless hours. The automated alerts and tracking features are exactly what we needed.",
    rating: 5,
  },
  {
    name: "Emily Rodriguez",
    role: "Teacher, Oakwood Elementary",
    image: "/placeholder.svg?height=80&width=80",
    content:
      "As a teacher, I love how easy it is to track student progress and communicate with parents. The mobile app is incredibly convenient.",
    rating: 5,
  },
  {
    name: "David Thompson",
    role: "Vice Principal, Metro High School",
    image: "/placeholder.svg?height=80&width=80",
    content:
      "The analytics and reporting features provide insights we never had before. Decision-making has become much more data-driven.",
    rating: 5,
  },
]

export function TestimonialsSection() {
  return (
    <section className="py-20 bg-slate-50">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center space-y-4 mb-16">
          <h2 className="text-3xl lg:text-4xl font-bold text-slate-900">Trusted by Educational Leaders</h2>
          <p className="text-xl text-slate-600 max-w-3xl mx-auto">
            See what school administrators, teachers, and staff are saying about their experience with Edulives.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {testimonials.map((testimonial, index) => (
            <Card key={index} className="border-slate-200 hover:shadow-lg transition-shadow duration-300">
              <CardContent className="p-6">
                <div className="flex items-center space-x-1 mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-slate-700 mb-6 italic">"{testimonial.content}"</p>
                <div className="flex items-center space-x-3">
                  <Image
                    src={testimonial.image || "/placeholder.svg"}
                    alt={testimonial.name}
                    width={48}
                    height={48}
                    className="rounded-full"
                  />
                  <div>
                    <div className="font-semibold text-slate-900">{testimonial.name}</div>
                    <div className="text-sm text-slate-600">{testimonial.role}</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}
