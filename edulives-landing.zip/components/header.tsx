"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { Menu, X } from "lucide-react"

export function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)

  return (
    <header className="sticky top-0 z-50 bg-white/95 backdrop-blur-sm border-b border-slate-200">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center">
            <Link href="/" className="flex items-center space-x-2">
              <Image src="/images/edulives-logo.png" alt="Edulives" width={160} height={60} className="h-10 w-auto" />
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-8">
            <Link href="#features" className="text-slate-700 hover:text-blue-600 transition-colors">
              Features
            </Link>
            <Link href="#roles" className="text-slate-700 hover:text-blue-600 transition-colors">
              Dashboards
            </Link>
            <Link href="#inventory" className="text-slate-700 hover:text-blue-600 transition-colors">
              Inventory
            </Link>
            <Link href="#pricing" className="text-slate-700 hover:text-blue-600 transition-colors">
              Pricing
            </Link>
            <Link href="#about" className="text-slate-700 hover:text-blue-600 transition-colors">
              About
            </Link>
            <Link href="#contact" className="text-slate-700 hover:text-blue-600 transition-colors">
              Contact
            </Link>
          </nav>

          {/* Desktop CTA Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            <Button variant="ghost" className="text-slate-700 hover:text-blue-600">
              Login
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">Get Started</Button>
          </div>

          {/* Mobile Menu Button */}
          <button className="md:hidden" onClick={() => setIsMenuOpen(!isMenuOpen)}>
            {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          </button>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-slate-200">
            <nav className="flex flex-col space-y-4">
              <Link href="#features" className="text-slate-700 hover:text-blue-600 transition-colors">
                Features
              </Link>
              <Link href="#roles" className="text-slate-700 hover:text-blue-600 transition-colors">
                Dashboards
              </Link>
              <Link href="#inventory" className="text-slate-700 hover:text-blue-600 transition-colors">
                Inventory
              </Link>
              <Link href="#pricing" className="text-slate-700 hover:text-blue-600 transition-colors">
                Pricing
              </Link>
              <Link href="#about" className="text-slate-700 hover:text-blue-600 transition-colors">
                About
              </Link>
              <Link href="#contact" className="text-slate-700 hover:text-blue-600 transition-colors">
                Contact
              </Link>
              <div className="flex flex-col space-y-2 pt-4">
                <Button variant="ghost" className="justify-start">
                  Login
                </Button>
                <Button className="bg-blue-600 hover:bg-blue-700 text-white justify-start">Get Started</Button>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  )
}
